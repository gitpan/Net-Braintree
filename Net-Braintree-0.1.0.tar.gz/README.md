# Braintree Perl Client Library

This project contains a client library for integrating with the [Braintree](http://www.braintreepaymentsolutions.com)
payment gateway.

